package com.example.android.graphgame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//Intermediate difficulty class where the user accesses all the Intermediate levels.
public class IntermediateDifficultyActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intermediate_difficulty);
    }
}
