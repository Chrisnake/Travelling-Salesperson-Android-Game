package com.example.android.graphgame;

/**
 * Created by christianvillegas on 19/01/2018.
 */

//TODO: Be able to find out the amount of stars that the user has earned
//TODO: Be able to change the total amount of stars if the user has earned more

public class Stars
{

}
