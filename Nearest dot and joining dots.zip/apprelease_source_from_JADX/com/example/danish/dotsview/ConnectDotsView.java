package com.example.danish.dotsview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Point;
import android.support.v4.internal.view.SupportMenu;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class ConnectDotsView extends View {
    private static final int BACKGROUND = -2236963;
    private static final int TOUCH_TOLERANCE_DP = 24;
    private Bitmap bmp;
    private Canvas canvasss;
    double[] f9d;
    private Bitmap fine;
    private boolean isPathStarted;
    private Bitmap mBitmap;
    private Canvas mCanvas;
    private int mLastPointIndex;
    private Paint mPaint;
    private Path mPath;
    private List<Point> mPoints;
    private int mTouchTolerance;
    boolean notcontain;
    int number;
    private Paint paint;
    Point point1;
    Point point2;
    int start;

    public ConnectDotsView(Context context) {
        super(context);
        this.notcontain = false;
        this.mPoints = new ArrayList();
        this.mLastPointIndex = 0;
        this.isPathStarted = false;
        this.f9d = new double[10];
        this.start = 0;
        this.mCanvas = new Canvas();
        this.mPath = new Path();
        initPaint();
        this.bmp = BitmapFactory.decodeResource(getResources(), C0220R.drawable.bright);
        this.fine = this.bmp.copy(Config.ARGB_8888, true);
    }

    public ConnectDotsView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.notcontain = false;
        this.mPoints = new ArrayList();
        this.mLastPointIndex = 0;
        this.isPathStarted = false;
        this.f9d = new double[10];
        this.start = 0;
        this.mCanvas = new Canvas();
        this.mPath = new Path();
        initPaint();
        this.bmp = BitmapFactory.decodeResource(getResources(), C0220R.drawable.bright);
        this.fine = this.bmp.copy(Config.ARGB_8888, true);
    }

    public ConnectDotsView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.notcontain = false;
        this.mPoints = new ArrayList();
        this.mLastPointIndex = 0;
        this.isPathStarted = false;
        this.f9d = new double[10];
        this.start = 0;
        this.mCanvas = new Canvas();
        this.mPath = new Path();
        initPaint();
        this.bmp = BitmapFactory.decodeResource(getResources(), C0220R.drawable.bright);
        this.fine = this.bmp.copy(Config.ARGB_8888, true);
    }

    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        clear();
    }

    protected void onDraw(Canvas canvas) {
        canvas.drawColor(BACKGROUND);
        canvas.drawBitmap(this.mBitmap, 0.0f, 0.0f, null);
        canvas.drawPath(this.mPath, this.mPaint);
        this.canvasss = canvas;
        for (Point point : this.mPoints) {
            Point point2;
            canvas.drawPoint((float) point2.x, (float) point2.y, this.mPaint);
        }
        if (this.notcontain && this.mPoints.size() >= this.mLastPointIndex) {
            point2 = (Point) this.mPoints.get(this.mLastPointIndex);
            bright((float) point2.x, (float) point2.y);
            invalidate();
        }
    }

    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        if (this.mPoints.contains(new Point((int) x, (int) y))) {
            this.notcontain = false;
        } else {
            this.notcontain = true;
        }
        switch (event.getAction()) {
            case 0:
                touch_start(x, y);
                invalidate();
                break;
            case 1:
                touch_up(x, y);
                invalidate();
                break;
            case 2:
                touch_move(x, y);
                invalidate();
                break;
        }
        return true;
    }

    private void touch_start(float x, float y) {
        for (int i = 0; i < this.mPoints.size(); i++) {
            Point point = (Point) this.mPoints.get(i);
            this.f9d[i] = Math.sqrt(Math.pow((double) (x - ((float) point.x)), 2.0d) + Math.pow((double) (y - ((float) point.y)), 2.0d));
        }
        this.mLastPointIndex = getMinValue(this.f9d);
        this.start = this.mLastPointIndex;
        if (checkPoint(x, y, this.mLastPointIndex)) {
            this.mPath.reset();
            this.isPathStarted = true;
            return;
        }
        this.isPathStarted = false;
    }

    private void touch_move(float x, float y) {
        if (this.isPathStarted) {
            this.mPath.reset();
            Point p;
            if (this.number == 1) {
                if (this.mLastPointIndex == 2) {
                    p = (Point) this.mPoints.get(2);
                    this.mPath.moveTo((float) p.x, (float) p.y);
                    if (checkPoint(x, y, 0)) {
                        p = (Point) this.mPoints.get(0);
                        this.mPath.lineTo((float) p.x, (float) p.y);
                        this.mCanvas.drawPath(this.mPath, this.mPaint);
                        this.mPath.reset();
                        this.mLastPointIndex = 5;
                        return;
                    }
                    this.mPath.lineTo(x, y);
                } else if (this.mLastPointIndex < 2) {
                    p = (Point) this.mPoints.get(this.mLastPointIndex);
                    this.mPath.moveTo((float) p.x, (float) p.y);
                    if (checkPoint(x, y, this.mLastPointIndex + 1)) {
                        p = (Point) this.mPoints.get(this.mLastPointIndex + 1);
                        this.mPath.lineTo((float) p.x, (float) p.y);
                        this.mCanvas.drawPath(this.mPath, this.mPaint);
                        this.mPath.reset();
                        this.mLastPointIndex++;
                        return;
                    }
                    this.mPath.lineTo(x, y);
                }
            } else if (this.number == 2) {
                if (this.mLastPointIndex == 3) {
                    p = (Point) this.mPoints.get(3);
                    this.mPath.moveTo((float) p.x, (float) p.y);
                    if (checkPoint(x, y, 0)) {
                        p = (Point) this.mPoints.get(0);
                        this.mPath.lineTo((float) p.x, (float) p.y);
                        this.mCanvas.drawPath(this.mPath, this.mPaint);
                        this.mPath.reset();
                        this.mLastPointIndex = 5;
                        return;
                    }
                    this.mPath.lineTo(x, y);
                } else if (this.mLastPointIndex < 3) {
                    p = (Point) this.mPoints.get(this.mLastPointIndex);
                    this.mPath.moveTo((float) p.x, (float) p.y);
                    if (checkPoint(x, y, this.mLastPointIndex + 1)) {
                        p = (Point) this.mPoints.get(this.mLastPointIndex + 1);
                        this.mPath.lineTo((float) p.x, (float) p.y);
                        this.mCanvas.drawPath(this.mPath, this.mPaint);
                        this.mPath.reset();
                        this.mLastPointIndex++;
                        return;
                    }
                    this.mPath.lineTo(x, y);
                }
            } else if (this.number == 3) {
                p = (Point) this.mPoints.get(this.mLastPointIndex);
                this.mPath.moveTo((float) p.x, (float) p.y);
                if (checkPoint(x, y, this.mLastPointIndex + 1)) {
                    p = (Point) this.mPoints.get(this.mLastPointIndex + 1);
                    this.mPath.lineTo((float) p.x, (float) p.y);
                    this.mCanvas.drawPath(this.mPath, this.mPaint);
                    this.mPath.reset();
                    this.mLastPointIndex++;
                    if (this.start != 0 && this.mLastPointIndex == 9) {
                        this.mLastPointIndex = 0;
                        return;
                    }
                    return;
                }
                this.mPath.lineTo(x, y);
            }
        }
    }

    private void touch_up(float x, float y) {
        this.mPath.reset();
        if (checkPoint(x, y, this.mLastPointIndex + 1) && this.isPathStarted) {
            Point p = (Point) this.mPoints.get(this.mLastPointIndex);
            this.mPath.moveTo((float) p.x, (float) p.y);
            p = (Point) this.mPoints.get(this.mLastPointIndex + 1);
            this.mPath.lineTo((float) p.x, (float) p.y);
            this.mCanvas.drawPath(this.mPath, this.mPaint);
            this.mPath.reset();
            this.mLastPointIndex++;
            this.isPathStarted = false;
        }
    }

    public void setPaint(Paint paint) {
        this.mPaint = paint;
    }

    public Bitmap getBitmap() {
        return this.mBitmap;
    }

    public void clear() {
        this.mBitmap = Bitmap.createBitmap(getWidth(), getHeight(), Config.ARGB_8888);
        this.mBitmap.eraseColor(BACKGROUND);
        this.mCanvas.setBitmap(this.mBitmap);
        invalidate();
    }

    private boolean checkPoint(float x, float y, int pointIndex) {
        if (pointIndex == this.mPoints.size() || pointIndex > this.mPoints.size()) {
            return false;
        }
        Point point = (Point) this.mPoints.get(pointIndex);
        if (x <= ((float) (point.x - this.mTouchTolerance)) || x >= ((float) (point.x + this.mTouchTolerance)) || y <= ((float) (point.y - this.mTouchTolerance)) || y >= ((float) (point.y + this.mTouchTolerance))) {
            return false;
        }
        return true;
    }

    public List<Point> getPoints() {
        return this.mPoints;
    }

    public void setPoints(List<Point> points, int number) {
        this.mPoints = points;
        this.number = number;
    }

    private void initPaint() {
        this.paint = new Paint();
        this.paint.setStyle(Style.STROKE);
        this.paint.setStrokeWidth(2.0f);
        this.paint.setColor(SupportMenu.CATEGORY_MASK);
        this.mPaint = new Paint();
        this.mPaint.setAntiAlias(true);
        this.mPaint.setDither(true);
        this.mPaint.setColor(ViewCompat.MEASURED_STATE_MASK);
        this.mPaint.setStyle(Style.STROKE);
        this.mPaint.setStrokeJoin(Join.ROUND);
        this.mPaint.setStrokeCap(Cap.ROUND);
        this.mPaint.setStrokeWidth(12.0f);
        this.mTouchTolerance = dp2px(24);
    }

    private int dp2px(int dp) {
        return (int) TypedValue.applyDimension(1, (float) dp, getContext().getResources().getDisplayMetrics());
    }

    public void bright(float x, float y) {
        this.bmp = BitmapFactory.decodeResource(getResources(), C0220R.drawable.bright);
        this.fine = this.bmp.copy(Config.ARGB_8888, true);
        this.canvasss.drawBitmap(this.fine, x, y - 24.0f, null);
        invalidate();
    }

    public int getMinValue(double[] array) {
        double minValue = array[0];
        int index = 0;
        for (int i = 1; i < this.mPoints.size(); i++) {
            if (array[i] < minValue) {
                minValue = array[i];
                index = i;
            }
        }
        return index;
    }
}
