package com.example.danish.dotsview;

import android.graphics.Point;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    int max = 3;
    int min = 1;
    int random;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0220R.layout.activity_main);
        this.random = new Random().nextInt((this.max - this.min) + 1) + this.min;
        ConnectDotsView view = (ConnectDotsView) findViewById(C0220R.id.dot1);
        List<Point> point;
        if (this.random == 1) {
            point = new ArrayList();
            point.add(new Point(getResources().getDisplayMetrics().widthPixels / 2, 200));
            point.add(new Point(300, 600));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) + 300, 600));
            view.setPoints(point, this.random);
        } else if (this.random == 2) {
            point = new ArrayList();
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) - 300, 200));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) - 300, 600));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) + 300, 600));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) + 300, 200));
            view.setPoints(point, this.random);
        } else if (this.random == 3) {
            point = new ArrayList();
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) - 300, 200));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) - 300, 600));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) + 300, 600));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) + 300, 200));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) - 300, 200));
            point.add(new Point(getResources().getDisplayMetrics().widthPixels / 2, 400));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) + 300, 600));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) + 300, 200));
            point.add(new Point(getResources().getDisplayMetrics().widthPixels / 2, 400));
            point.add(new Point((getResources().getDisplayMetrics().widthPixels / 2) - 300, 600));
            view.setPoints(point, this.random);
        }
    }
}
