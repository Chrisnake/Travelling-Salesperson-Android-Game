package com.example.android.graphgame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ELV1Activity extends AppCompatActivity
{
//TODO: Research how to input our nodes/dots onto the phone screen and keep the nodes/dots at the same position even when the screen resolution changes
//TODO: Find a way to input the nodes and allow the user to click on a node to draw a line.
//TODO: After the user clicks on a node and a new line is drawn, add the weight onto the total weight to show the users score
//TODO: Once the user has gone from the starting node and has gone through all of the streets, end the level and move onto another activity.

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elv1);
    }

    //Create the nodes from buttons or image buttons to allow on click listener.

}
