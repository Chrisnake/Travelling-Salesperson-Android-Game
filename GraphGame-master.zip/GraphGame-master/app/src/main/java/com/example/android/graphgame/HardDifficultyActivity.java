package com.example.android.graphgame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//Hard difficulty class where the user accesses all the hard levels.
public class HardDifficultyActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hard_difficulty);
    }
}
