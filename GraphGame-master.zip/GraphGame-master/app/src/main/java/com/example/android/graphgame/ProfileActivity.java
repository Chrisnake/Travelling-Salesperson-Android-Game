package com.example.android.graphgame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ProfileActivity extends AppCompatActivity {
//TODO: Use the stars variable to allow the user to view the total amount of stars they've collected.
//TODO: Allow the user to register and login on this profile page to enable them to share their scores on an online leaderboard and connect to social media.
//TODO: Enable the user to change the colour of the trail
//TODO: Allow the user to add a profile picture

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}
